package jwtc.chess.board;

public class BoardStatics extends BoardConstants {
    // used by pgn notation generation - get the name of the piece on position @p
    // when no piece on this field, debug ouput is given, this will reveal a bug elsewhere

}
